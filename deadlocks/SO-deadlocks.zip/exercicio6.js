class BankersAlgorithm {
    constructor(available, maxNeed, allocation) {
        this.available = available;  // Vetor de recursos disponíveis
        this.maxNeed = maxNeed;      // Matriz de necessidade máxima
        this.allocation = allocation; // Matriz de alocação atual
        this.numProcesses = maxNeed.length;
        this.numResources = available.length;
        this.need = this.calculateNeed();
    }

    // Calcula a matriz Need = MaxNeed - Allocation
    calculateNeed() {
        let need = [];
        for (let i = 0; i < this.numProcesses; i++) {
            need[i] = [];
            for (let j = 0; j < this.numResources; j++) {
                need[i][j] = this.maxNeed[i][j] - this.allocation[i][j];
            }
        }
        return need;
    }

    // Verifica se um estado é seguro
    isSafeState() {
        let work = [...this.available]; // Copia dos recursos disponíveis
        let finish = Array(this.numProcesses).fill(false); // Processos finalizados
        let safeSequence = [];

        while (safeSequence.length < this.numProcesses) {
            let allocatedInThisCycle = false;

            for (let i = 0; i < this.numProcesses; i++) {
                if (!finish[i] && this.canProcessExecute(i, work)) {
                    // Libera recursos e marca como finalizado
                    for (let j = 0; j < this.numResources; j++) {
                        work[j] += this.allocation[i][j];
                    }
                    safeSequence.push(i);
                    finish[i] = true;
                    allocatedInThisCycle = true;
                }
            }

            if (!allocatedInThisCycle) {
                return { safe: false, sequence: [] }; // Deadlock encontrado
            }
        }

        return { safe: true, sequence: safeSequence };
    }

    // Verifica se um processo pode ser executado com os recursos disponíveis
    canProcessExecute(processIndex, work) {
        for (let j = 0; j < this.numResources; j++) {
            if (this.need[processIndex][j] > work[j]) {
                return false;
            }
        }
        return true;
    }

    // Tenta atender uma requisição de alocação de um processo
    requestResources(processIndex, request) {
        for (let j = 0; j < this.numResources; j++) {
            if (request[j] > this.need[processIndex][j] || request[j] > this.available[j]) {
                return false; // Pedido inválido ou indisponível
            }
        }

        // Concede temporariamente os recursos
        for (let j = 0; j < this.numResources; j++) {
            this.available[j] -= request[j];
            this.allocation[processIndex][j] += request[j];
            this.need[processIndex][j] -= request[j];
        }

        // Verifica se ainda estamos em estado seguro
        let checkSafe = this.isSafeState();
        if (!checkSafe.safe) {
            // Reverte a alocação se o estado não for seguro
            for (let j = 0; j < this.numResources; j++) {
                this.available[j] += request[j];
                this.allocation[processIndex][j] -= request[j];
                this.need[processIndex][j] += request[j];
            }
            return false;
        }

        return true;
    }
}

// SIMULAÇÃO DE USO
const available = [3, 3, 2]; // Recursos disponíveis
const maxNeed = [
    [7, 5, 3],
    [3, 2, 2],
    [9, 0, 2],
    [2, 2, 2],
    [4, 3, 3]
];
const allocation = [
    [0, 1, 0],
    [2, 0, 0],
    [3, 0, 2],
    [2, 1, 1],
    [0, 0, 2]
];

const bankers = new BankersAlgorithm(available, maxNeed, allocation);

console.log("Estado seguro inicial:", bankers.isSafeState());

// Simulando um pedido de recursos pelo processo 1
const request = [1, 2, 2];
const processIndex = 1; // APROVADO
// const processIndex = 2; // NEGADO
if (bankers.requestResources(processIndex, request)) {
    console.log(`Requisição aprovada para o processo ${processIndex}`);
} else {
    console.log(`Requisição negada para o processo ${processIndex}`);
}

console.log("Novo estado seguro:", bankers.isSafeState());