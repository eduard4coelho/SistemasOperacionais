class Recurso {
    constructor(nome) {
        this.nome = nome;
        this.ocupado = false;
    }

    async adquirir(processo) {
        while (this.ocupado) {
            await new Promise((resolve) => setTimeout(resolve, 100)); // Espera até o recurso estar disponível
        }
        this.ocupado = true;
        console.log(`${processo} adquiriu ${this.nome}`);
    }

    liberar(processo) {
        this.ocupado = false;
        console.log(`${processo} liberou ${this.nome}`);
    }
}

const recursoA = new Recurso("Recurso A");
const recursoB = new Recurso("Recurso B");

const processosEmDeadlock = new Set(); // Armazena processos presos

async function processo(nome, primeiroRecurso, segundoRecurso, delay) {
    await new Promise((resolve) => setTimeout(resolve, delay)); // Pequeno atraso para intercalar processos

    await primeiroRecurso.adquirir(nome);
    console.log(`${nome} segurou ${primeiroRecurso.nome}, tentando pegar ${segundoRecurso.nome}...`);

    // 🚨 Timer para detectar deadlock
    const deadlockTimer = setTimeout(() => {
        processosEmDeadlock.add(nome);
        console.error(`⚠️ DEADLOCK DETECTADO: ${nome} está preso esperando ${segundoRecurso.nome}!`);
    }, 2000); // Se ficar preso por 2s, assume que está em deadlock

    await new Promise((resolve) => setTimeout(resolve, 1000)); // Simula trabalho com o primeiro recurso

    console.log(`${nome} ainda está esperando por ${segundoRecurso.nome}...`);
    await segundoRecurso.adquirir(nome); // Aqui ocorre o deadlock!

    clearTimeout(deadlockTimer); // Se conseguiu o segundo recurso, não está em deadlock

    console.log(`${nome} conseguiu ambos os recursos!`);

    segundoRecurso.liberar(nome);
    primeiroRecurso.liberar(nome);

    processosEmDeadlock.delete(nome); // Se desbloqueou, remove da lista de deadlocks
}

// 🔍 Função para exibir processos em deadlock após um tempo
setInterval(() => {
    if (processosEmDeadlock.size > 0) {
        console.error(`⚠️ DEADLOCK ATIVO: Os seguintes processos estão presos: ${[...processosEmDeadlock].join(', ')}`);
    }
}, 3000); // A cada 3 segundos, verifica deadlocks

async function iniciar() {
    // 🚨 Alternamos a ordem de aquisição dos recursos para forçar deadlock
    processo("Processo 1", recursoA, recursoB, 0);
    processo("Processo 2", recursoA, recursoB, 100);
    processo("Processo 3", recursoB, recursoA, 200);
    processo("Processo 4", recursoB, recursoA, 300);
}

iniciar();

