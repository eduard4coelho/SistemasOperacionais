function avestruzAlgorithm() {
    try {
        // Código que pode gerar um erro
        let result = riskyOperation();
        console.log("Operação bem-sucedida:", result);
    } catch (error) {
        // Algoritmo do avestruz: Ignora o erro completamente
    }
}

function riskyOperation() {
    // Simulação de uma operação que pode falhar
    if (Math.random() < 0.5) {
        throw new Error("Algo deu errado!");
    }
    return "Sucesso!";
}

// Executando várias vezes para testar
for (let i = 0; i < 5; i++) {
    avestruzAlgorithm();
}