class Recurso {
    constructor(nome) {
        this.nome = nome;
        this.ocupado = false;
    }

    async tentarAdquirir(processo, timeout = 2000) {
        const startTime = Date.now();
        while (this.ocupado) {
            if (Date.now() - startTime > timeout) {
                console.warn(`⏳ ${processo} desistiu de esperar por ${this.nome} e tentará mais tarde.`);
                return false;
            }
            await new Promise(resolve => setTimeout(resolve, 100));
        }
        this.ocupado = true;
        console.log(`✅ ${processo} adquiriu ${this.nome}`);
        return true;
    }

    liberar(processo) {
        this.ocupado = false;
        console.log(`🔓 ${processo} liberou ${this.nome}`);
    }
}

// Criando os recursos
const recursoA = new Recurso("Recurso A");
const recursoB = new Recurso("Recurso B");

// Processo com estratégia para evitar deadlock
async function processo(nome, recurso1, recurso2, delay) {
    await new Promise(resolve => setTimeout(resolve, delay));

    // Ordenação dos recursos sempre na mesma ordem
    const [primeiro, segundo] = recurso1.nome < recurso2.nome ? [recurso1, recurso2] : [recurso2, recurso1];

    while (true) {
        if (!await primeiro.tentarAdquirir(nome)) {
            await new Promise(resolve => setTimeout(resolve, Math.random() * 1000)); // Espera aleatória antes de tentar de novo
            continue;
        }

        console.log(`${nome} segurou ${primeiro.nome}, tentando pegar ${segundo.nome}...`);
        await new Promise(resolve => setTimeout(resolve, 500)); // Simula trabalho

        if (!await segundo.tentarAdquirir(nome)) {
            primeiro.liberar(nome);
            await new Promise(resolve => setTimeout(resolve, Math.random() * 1000)); // Espera antes de recomeçar
            continue;
        }

        console.log(`🎉 ${nome} conseguiu ambos os recursos! Executando tarefa...`);
        await new Promise(resolve => setTimeout(resolve, 1000)); // Simula trabalho principal

        // Libera os recursos após o uso
        segundo.liberar(nome);
        primeiro.liberar(nome);
        break;
    }
}

// Função para iniciar os processos
async function iniciar() {
    processo("Processo 1", recursoA, recursoB, 0);
    processo("Processo 2", recursoA, recursoB, 100);
    processo("Processo 3", recursoB, recursoA, 200);
    processo("Processo 4", recursoB, recursoA, 300);
}

// Inicia os processos
iniciar();
